/* Magic Mirror Config Sample
*
* By Michael Teeuw http://michaelteeuw.nl
* MIT Licensed.
*/
var config = {
	"port": 8080,
	"language": "en",
	"timeFormat": 24,
	"units": "imperial",
	"modules": [
		{
			"module": "alert"
		},
		{
			"module": "MMM-Admin-Interface"
		},
		{
			"module": "updatenotification",
			"position": "top_bar"
		},
		{
			"module": "clock",
			"position": "lower_third"
		},
		{
			"module": "calendar",
			"header": "US Holidays",
			"position": "top_left",
			"config": {
				"calendars": [
					{
						"symbol": "calendar-check-o ",
						"url": "webcal://www.calendarlabs.com/templates/ical/US-Holidays.ics"
					}
				]
			}
		},
		{
			"module": "currentweather",
			"position": "top_right",
			"config": {
				"location": "Honolulu",
				"locationID": "",
				"appid": "3feeca59bc965347c49299986569ed49"
			}
		},

		// {
		// 	"module": "MMM-Globe",
		// 	"position": "lower_third",
		// 	"config": {
		// 		"size": "medium",
		// 		"dayLength": 38,
		// 		"viewAngle": 15,
		// 		"introLinesDuration": 2000,
		// 		"receiveExternalLocations": 0,
		// 		"locations": [
		// 			{
		// 				"lat": 21.308231,
		// 				"lng": -157.86294,
		// 				"label": "Oceanit"
		// 			}
		// 		]
		// 	}
		// }






	],
	"address": "localhost",
	"ipWhitelist": []
};
/*************** DO NOT EDIT THE LINE BELOW ***************/
if (typeof module !== 'undefined') {module.exports = config;}