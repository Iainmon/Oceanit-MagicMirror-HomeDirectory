echo "\033[32mMagicMirror installation successful!"
exit 0
