defaultData = [

    {lat:42.35843,lng:-71.05977, label: "Boston"},
    {lat:25.77427,lng:-80.19366, label: "Miami"},
    {lat:37.77493,lng:-122.41942, label: "San Francisco"},
    {lat:-23.5475,lng:-46.63611, label: "Sao Paulo"},
    {lat:-12.04318,lng:-77.02824, label: "Lima"},
    {lat:21.30694,lng:-157.85833, label: "Honolulu"},
    {lat:-31.95224,lng:115.8614, label: "Perth"},
    {lat:-33.86785,lng:151.20732, label: "Sydney"},
    {lat: -42, lng: 174, label: "New Zealand"},
    {lat:22.28552,lng:114.15769, label: "Hong Kong"},
    {lat:19.07283,lng:72.88261, label: "Mumbai"},
    {lat:30.06263,lng:31.24967, label:"Cairo"},
    {lat:-33.92584,lng:18.42322, label:"Cape Town"},
    {lat:52.52437,lng:13.41053, label:"Berlin"},
    {lat:55.95206,lng:-3.19648, label:"Edinburgh"},
    {lat:55.75222,lng:37.61556, label:"Moscow"}
]