# MagicPlugins
@nhubbard does Magic Mirror 2 plugins.
